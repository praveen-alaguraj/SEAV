from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # run LIDAR node
        Node(
            package='rplidar_ros',
            executable='rplidar_composition',
            name='rplidar_node',
            output='screen',
            parameters=[{
                'serial_port': '/dev/ttyUSB0',
                'serial_baudrate': 115200,
                'frame_id': 'laser_frame',
                'inverted': False,
                'angle_compensate': True
            }]
        ),

        #odom → base_link
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='odom_tf_pub',
            arguments=['0', '0', '0', '0', '0', '0', 'odom', 'base_link']
        ),

        # publish base_link → laser_frame
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='laser_tf_pub',
            arguments=['0', '0', '0.1', '0', '0', '0', 'base_link', 'laser_frame']
        )
    ])
