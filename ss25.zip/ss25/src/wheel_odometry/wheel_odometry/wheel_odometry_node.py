import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped
from tf2_ros import TransformBroadcaster
import serial

class WheelOdometryNode(Node):
    def __init__(self):
        super().__init__('wheel_odometry_node')
        self.publisher = self.create_publisher(Odometry, 'odom', 10)

        self.declare_parameter('serial_port', '/dev/ttyUSB0')
        self.declare_parameter('baudrate', 57600)

        port = self.get_parameter('serial_port').get_parameter_value().string_value
        baudrate = self.get_parameter('baudrate').get_parameter_value().integer_value

        try:
            self.ser = serial.Serial(port, baudrate, timeout=1)
            self.get_logger().info(f"Serial connection established on {port} at {baudrate} baud.")
        except Exception as e:
            self.get_logger().error(f"Failed to open serial port: {e}")
            raise

        self.distance_per_pulse = 0.000166  # meters per pulse
        self.total_distance = 0.0
        self.last_pulse = None
        self.last_time = self.get_clock().now()

        self.tf_broadcaster = TransformBroadcaster(self)
        self.timer = self.create_timer(0.1, self.read_serial)

        # Optionally trigger encoder stream from Arduino
        try:
            self.ser.write(b"e\r")
        except Exception as e:
            self.get_logger().warn(f"Failed to send init command to Arduino: {e}")

    def read_serial(self):
        try:
            line = self.ser.readline().decode('utf-8').strip()
            if not line or not line.startswith("PULSE:"):
                return

            pulse = int(line.split(":")[1])

            if self.last_pulse is None:
                self.last_pulse = pulse
                return

            delta_pulse = pulse - self.last_pulse
            current_time = self.get_clock().now()
            dt = (current_time - self.last_time).nanoseconds / 1e9

            if dt <= 0:
                return

            delta_distance = delta_pulse * self.distance_per_pulse
            velocity = delta_distance / dt
            self.total_distance += delta_distance

            # Odometry message
            msg = Odometry()
            msg.header.stamp = current_time.to_msg()
            msg.header.frame_id = 'odom'
            msg.child_frame_id = 'base_link'
            msg.pose.pose.position.x = self.total_distance
            msg.pose.pose.orientation.w = 1.0
            msg.twist.twist.linear.x = velocity
            self.publisher.publish(msg)

            # Transform
            t = TransformStamped()
            t.header.stamp = current_time.to_msg()
            t.header.frame_id = 'odom'
            t.child_frame_id = 'base_link'
            t.transform.translation.x = self.total_distance
            t.transform.rotation.w = 1.0
            self.tf_broadcaster.sendTransform(t)

            self.last_pulse = pulse
            self.last_time = current_time

        except Exception as e:
            self.get_logger().warn(f"Error reading serial: {e}")

def main(args=None):
    rclpy.init(args=args)
    node = WheelOdometryNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
