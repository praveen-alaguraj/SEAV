from setuptools import find_packages, setup
import os
from glob import glob
package_name = 'summary'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
  
    data_files=[
    ('share/ament_index/resource_index/packages',
        ['resource/summary']),
    ('share/summary', ['package.xml']),
     (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
],

    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='pi',
    maintainer_email='pi@todo.todo',
    description='Package to launch motor, lidar, and slam nodes',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [],
    },
)
