from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    config_path = os.path.join(
        get_package_share_directory('summary'),
        'config',
        'slam_toolbox_params.yaml'
    )

    return LaunchDescription([
        # Motor driver node (Pi)
        Node(
            package='my_motor_driver',
            executable='cmd_vel_to_serial',
            name='motor_driver_node',
            output='screen',
        ),

        # LiDAR node (Pi)
        Node(
            package='sllidar_ros2',
            executable='sllidar_node',
            name='sllidar_node',
            output='screen',
            parameters=[
                {'serial_port': '/dev/lidar'},
                {'serial_baudrate': 115200},
                {'frame_id': 'laser'}
            ]
        ),

        # SLAM node
        Node(
            package='slam_toolbox',
            executable='sync_slam_toolbox_node',
            name='slam_node',
            output='screen',
            parameters=[config_path]
        ),

        # Static transform between base_link and laser
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='static_tf',
            arguments=['0', '0', '0.1', '0', '0', '0', 'base_link', 'laser'],
            output='screen'
        ),

       
    ])
