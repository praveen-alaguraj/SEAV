from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    config_path = os.path.join(
        get_package_share_directory('summary'),
        'config',
        'slam_toolbox_params.yaml'
    )

    print(f"Using slam_toolbox config file: {config_path}")

    return LaunchDescription([
        # Motor driver node (reads from /safe_cmd_vel)
        Node(
            package='my_motor_driver',
            executable='cmd_vel_to_serialcopy',
            name='motor_driver_node',
            output='screen',
            remappings=[
                ('/cmd_vel','/safe_cmd_vel')  # Listen to safe command
            ]
        ),

        # Safety Control Node (filters /cmd_vel + /scan)
        Node(
            package='safety_control',
            executable='obstacle_avoidercopy',
            name='obstacle_avoider',
            output='screen',
        ),

        # LiDAR node
        Node(
            package='sllidar_ros2',
            executable='sllidar_node',
            name='sllidar_node',
            output='screen',
            parameters=[
                {'serial_port': '/dev/ttyUSB1'},
                {'serial_baudrate': 115200},
                {'frame_id': 'laser'}
            ]
        ),

        # Wheel Odometry
        Node(
            package='wheel_odometry',
            executable='wheel_odometry_node',
            name='wheel_odometry_node',
            output='screen',
            remappings=[
                ('/wheel_odom', '/odom')
            ],
            parameters=[
                {'serial_port': '/dev/ttyUSB0'},
                {'baudrate': 9600}
            ]
        ),

        # SLAM Toolbox
        Node(
            package='slam_toolbox',
            executable='sync_slam_toolbox_node',
            name='slam_node',
            output='screen',
            parameters=[{'use_sim_time': False}],
            arguments=['--ros-args', '--params-file', config_path]
        ),

        # Static TF
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='static_tf',
            arguments=['0', '0', '0.1', '0', '0', '0', 'base_link', 'laser'],
            output='screen'
        ),
    ])
