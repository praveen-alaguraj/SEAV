import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan

class ObstacleAvoider(Node):
    def __init__(self):
        super().__init__('obstacle_avoider')

        self.cmd_vel_sub = self.create_subscription(
            Twist,
            '/cmd_vel',
            self.cmd_vel_callback,
            10)

        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10)

        self.cmd_vel_pub = self.create_publisher(
            Twist,
            '/safe_cmd_vel',
            10)

        self.latest_cmd = Twist()

        # Safety distances (in meters) with 10cm buffer
        self.front_limit = 1.25
        self.back_limit =  1.25
        self.left_limit =  1.25
        self.right_limit = 1.25

        # Obstacle flags
        self.front_blocked = False
        self.back_blocked = False
        self.left_blocked = False
        self.right_blocked = False

    def cmd_vel_callback(self, msg):
        self.latest_cmd = msg
        self.evaluate_and_publish()

    def scan_callback(self, scan: LaserScan):
        ranges = scan.ranges
        total = len(ranges)

        # Sector ranges (±30° front/back, ±60° left/right)
        front_angles = ranges[total//3: 2*total//3]
        back_angles = ranges[0:total//12] + ranges[-total//12:]
        left_angles = ranges[5*total//6 : total]  # left = ~+150° to 180°
        right_angles = ranges[0 : total//6]       # right = ~0° to 30°

        def has_obstacle(angles, limit):
            valid = [d for d in angles if d > 0.05]  # filter out 0.0 and inf
            return min(valid, default=99) < limit

        # Update obstacle flags
        self.front_blocked = has_obstacle(front_angles, self.front_limit)
        self.back_blocked = has_obstacle(back_angles, self.back_limit)
        self.left_blocked = has_obstacle(left_angles, self.left_limit)
        self.right_blocked = has_obstacle(right_angles, self.right_limit)

        self.evaluate_and_publish()

    def evaluate_and_publish(self):
        cmd = Twist()

        blocked = []

        if self.front_blocked and self.latest_cmd.linear.x > 0.0:
            blocked.append("forward")
            cmd.linear.x = 0.0
        elif self.back_blocked and self.latest_cmd.linear.x < 0.0:
            blocked.append("backward")
            cmd.linear.x = 0.0
        else:
            cmd.linear.x = self.latest_cmd.linear.x

        if self.left_blocked and self.latest_cmd.angular.z > 0.0:
            blocked.append("left turn")
            cmd.angular.z = 0.0
        elif self.right_blocked and self.latest_cmd.angular.z < 0.0:
            blocked.append("right turn")
            cmd.angular.z = 0.0
        else:
            cmd.angular.z = self.latest_cmd.angular.z

        if blocked:
            self.get_logger().warn(f"Obstacle detected! Blocking: {', '.join(blocked)}")

        self.cmd_vel_pub.publish(cmd)

def main(args=None):
    rclpy.init(args=args)
    node = ObstacleAvoider()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
