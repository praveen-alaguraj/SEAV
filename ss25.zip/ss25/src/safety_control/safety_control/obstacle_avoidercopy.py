import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan

class ObstacleAvoidercopy(Node):
    def __init__(self):
        super().__init__('obstacle_avoider')

        # Subscribe to original velocity command topic
        self.cmd_vel_sub = self.create_subscription(
            Twist,
            '/cmd_vel',
            self.cmd_vel_callback,
            10)

        # Subscribe to LiDAR scan data
        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10)

        # Publisher for safe velocity command
        self.cmd_vel_pub = self.create_publisher(
            Twist,
            '/safe_cmd_vel',
            10)

        # Stores the latest received velocity command
        self.latest_cmd = Twist()

        # Whether an obstacle is too close in front
        self.obstacle_near = False

    def cmd_vel_callback(self, msg):
        """
        Called when new /cmd_vel data is received.
        This is the trigger to decide whether it's safe to move.
        """
        self.latest_cmd = msg
        self.evaluate_and_publish()

    def scan_callback(self, scan):
        """
        Called when new /scan data is received.
        Only updates the obstacle detection state.
        Does NOT publish any cmd_vel by itself.
        """
        # Check the center 1/3 of LiDAR scan
        center_scan = scan.ranges[len(scan.ranges)//3 : 2*len(scan.ranges)//3]
        # Update obstacle flag
        self.obstacle_near = min(center_scan) < 0.5

    def evaluate_and_publish(self):
        """
        Evaluates whether it's safe to move forward.
        Only called after a new /cmd_vel is received.
        """
        safe_cmd = Twist()

        # If we are trying to move forward but there's an obstacle: stop
        if self.obstacle_near and self.latest_cmd.linear.x > 0.0:
            self.get_logger().warn("Obstacle ahead! Stopping forward motion.")
            safe_cmd.linear.x = 0.0
            safe_cmd.angular.z = self.latest_cmd.angular.z  # allow turning in place
        else:
            safe_cmd = self.latest_cmd

        self.cmd_vel_pub.publish(safe_cmd)

def main(args=None):
    rclpy.init(args=args)
    node = ObstacleAvoidercopy()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
