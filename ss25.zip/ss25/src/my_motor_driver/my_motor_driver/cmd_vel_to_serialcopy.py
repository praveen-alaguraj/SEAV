import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import serial

class CmdVelToSerial(Node):
    def __init__(self):
        super().__init__('cmd_vel_to_serial')

        # Open serial port
        try:
            self.serial_port = serial.Serial('/dev/ttyUSB0', 57600, timeout=1.0)
            self.get_logger().info(" Serial port /dev/ttyUSB0 opened at 57600 baud.")
        except Exception as e:
            self.get_logger().error(f"Failed to open serial port: {e}")
            raise

        # Subscribe to safe velocity commands
        self.subscription = self.create_subscription(
            Twist,
            '/safe_cmd_vel',   # Filtered command from obstacle_avoider
            self.listener_callback,
            10
        )

        # Constant steering speed (tune if needed)
        self.constant_steering_speed = 100
        self.get_logger().info('Listening to /safe_cmd_vel (teleop with constant steering)...')

    def listener_callback(self, msg):
        linear = msg.linear.x
        angular = msg.angular.z

        # Map linear velocity to drive speed
        drive_speed = int(linear * 255)
        drive_speed = max(min(drive_speed, 255), -255)

        # Map angular velocity to fixed steering
        if angular > 0.1:
            steer_speed = -self.constant_steering_speed  # Left turn
        elif angular < -0.1:
            steer_speed = self.constant_steering_speed   # Right turn
        else:
            steer_speed = 0  # Straight

        # Send motor command: "m <drive> <steer>"
        command = f"m {drive_speed} {steer_speed}\r"
        try:
            self.serial_port.write(command.encode())
            self.serial_port.flush()
            self.get_logger().info(f"Sent: {command.strip()}")
        except Exception as e:
            self.get_logger().warn(f"Serial write failed: {e}")

def main(args=None):
    rclpy.init(args=args)
    node = CmdVelToSerial()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()
